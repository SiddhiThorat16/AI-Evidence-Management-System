import { useState } from 'react'
import LoginPage from './pages/LoginPage.jsx'
import SuccessPage from './pages/SuccessPage.jsx'

export default function App() {
  const [user, setUser] = useState(null)

  return user ? (
    <SuccessPage user={user} onContinue={() => alert('Dashboard screen not built yet.')} />
  ) : (
    <LoginPage onSuccess={setUser} />
  )
}
