import { CheckCircleIcon, UserIcon, BadgeIcon, ArrowIcon } from '../icons.jsx'

export default function SuccessPage({ user, onContinue }) {
  return (
    <div className="screen">
      <div className="success-card">
        <CheckCircleIcon />
        <h2>Login Successful!</h2>
        <p className="subtitle">Welcome to the system</p>

        <div className="user-card">
          <div className="avatar">
            <UserIcon />
          </div>
          <div className="user-info">
            <p className="user-name">{user.name}</p>
            <p className="user-role">
              <BadgeIcon /> {user.role}
            </p>
          </div>
        </div>

        <p className="success-note">
          You are now logged in to the AI Digital Evidence Management System.
        </p>

        <button className="dashboard-button" onClick={onContinue}>
          Go to Dashboard <ArrowIcon />
        </button>
      </div>
    </div>
  )
}
