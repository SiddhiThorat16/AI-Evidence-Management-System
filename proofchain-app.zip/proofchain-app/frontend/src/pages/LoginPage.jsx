import { useState } from 'react'
import { verifySecretKey } from '../api.js'
import { ShieldIcon, LockIcon, KeyIcon, EyeIcon, ArrowIcon } from '../icons.jsx'

export default function LoginPage({ onSuccess }) {
  const [secretKey, setSecretKey] = useState('')
  const [showKey, setShowKey] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')

    if (!secretKey.trim()) {
      setError('Enter your secret access key to continue.')
      return
    }

    setLoading(true)
    try {
      const { ok, data } = await verifySecretKey(secretKey.trim())
      if (ok && data.success) {
        onSuccess(data.user)
      } else {
        setError(data.message || 'Invalid secret key. Please try again.')
      }
    } catch {
      setError('Could not reach the server. Is the backend running?')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="screen">
      <div className="login-layout">
        <section className="brand-panel">
          <ShieldIcon />
          <h1 className="brand-title">
            AI Digital Evidence
            <br />
            <span className="accent">Management System</span>
          </h1>
          <p className="brand-tagline">Secure &nbsp;•&nbsp; Manage &nbsp;•&nbsp; Analyze</p>
          <hr className="divider" />
          <p className="brand-note">
            Access the system using your unique secret key provided by the organization.
          </p>
          <p className="authorized-note">
            <LockIcon /> Authorized users only
          </p>
        </section>

        <section className="login-card">
          <h2>Secure Login</h2>
          <p className="subtitle">Enter your secret access key to continue</p>

          <form onSubmit={handleSubmit} noValidate>
            <label className="input-wrapper" htmlFor="secret-key">
              <span className="input-icon">
                <KeyIcon />
              </span>
              <input
                id="secret-key"
                type={showKey ? 'text' : 'password'}
                placeholder="Enter Secret Access Key"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                disabled={loading}
                autoComplete="off"
              />
              <button
                type="button"
                className="toggle-visibility"
                onClick={() => setShowKey((s) => !s)}
                aria-label={showKey ? 'Hide secret key' : 'Show secret key'}
              >
                <EyeIcon crossed={showKey} />
              </button>
            </label>

            {error && <p className="error-text" role="alert">{error}</p>}

            <button type="submit" className="login-button" disabled={loading}>
              {loading ? 'Verifying…' : (
                <>
                  Login <ArrowIcon />
                </>
              )}
            </button>
          </form>

          <p className="confidential-note">
            <LockIcon /> Your access key is confidential and unique to you.
          </p>
        </section>
      </div>
    </div>
  )
}
