const API_BASE = '/api'

export async function verifySecretKey(secretKey) {
  const response = await fetch(`${API_BASE}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ secretKey }),
  })
  const data = await response.json()
  return { ok: response.ok, data }
}
