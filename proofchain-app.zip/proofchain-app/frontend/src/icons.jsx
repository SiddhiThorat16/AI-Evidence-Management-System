export function ShieldIcon({ size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <path
        d="M32 4 L56 14 V30 C56 46 46 56 32 60 C18 56 8 46 8 30 V14 Z"
        stroke="#4f9bff"
        strokeWidth="2.5"
        fill="rgba(79,155,255,0.08)"
      />
      <path
        d="M32 20 C26 20 22 24 22 30 C22 36 26 42 32 46 C38 42 42 36 42 30 C42 24 38 20 32 20 Z"
        stroke="#4f9bff"
        strokeWidth="2"
        fill="none"
      />
      <path d="M32 24 v18 M27 30 q5 -4 10 0 M27 34 q5 -4 10 0 M27 38 q5 -3 10 0" stroke="#4f9bff" strokeWidth="1.4" fill="none" />
    </svg>
  )
}

export function LockIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="11" width="14" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
      <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  )
}

export function KeyIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <circle cx="8" cy="12" r="4" stroke="currentColor" strokeWidth="1.8" />
      <path d="M11.5 12H21M17.5 12V16M21 12V15" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  )
}

export function EyeIcon({ crossed }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path
        d="M2 12C4.5 7.5 8 5.5 12 5.5C16 5.5 19.5 7.5 22 12C19.5 16.5 16 18.5 12 18.5C8 18.5 4.5 16.5 2 12Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.6" />
      {crossed && <line x1="3" y1="21" x2="21" y2="3" stroke="currentColor" strokeWidth="1.6" />}
    </svg>
  )
}

export function ArrowIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path d="M5 12H19M13 6L19 12L13 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function CheckCircleIcon() {
  return (
    <svg width="72" height="72" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="#22c55e" strokeWidth="1.6" fill="rgba(34,197,94,0.12)" />
      <path d="M7.5 12.5L10.5 15.5L16.5 9" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function UserIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="1.8" />
      <path d="M4 20c0-4 3.5-7 8-7s8 3 8 7" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  )
}

export function BadgeIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
      <path d="M12 2 22 6 V12 C22 18 17.5 22 12 23 C6.5 22 2 18 2 12 V6 Z" fill="#3b82f6" />
      <path d="M8 12.5L10.8 15L16 9.5" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
