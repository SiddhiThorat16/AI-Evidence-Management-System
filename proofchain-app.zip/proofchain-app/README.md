# AI Digital Evidence Management System — Login Flow

Screens 1 (Secret Key Login) and 2 (Login Successful) from your reference image,
built as a real full-stack app:

- **Frontend:** React (Vite)
- **Backend:** Python (Flask)
- **Database:** SQLite, with secret keys stored as salted hashes (never plain text)

## How the secret key verification works

1. The React login form sends the entered key to `POST /api/login`.
2. Flask fetches every stored user hash from the `users` table and checks the
   submitted key against each with `werkzeug.security.check_password_hash`
   (the same technique normally used for password verification).
3. On a match, Flask returns the user's `name` and `role`, and the frontend
   swaps the login screen for the "Login Successful" screen and displays them.
4. On no match, Flask returns a 401 and the login card shows an inline error.

A demo account is auto-seeded the first time the backend runs:

```
Secret key: SNEHAL-INV-2026-XK92
Name:       Snehal Supekar
Role:       Investigator
```

(This matches the name/role shown in your reference screenshot. Change or
remove it in `backend/database.py` before using this for anything real.)

## Run it

### 1. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

This starts the API on `http://localhost:5000` and creates
`backend/evidence_system.db` automatically on first run.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`). The dev server
proxies `/api/*` calls to the Flask backend, so no CORS config is needed
beyond what's already in `app.py`.

## Adding more authorized users

From a Python shell in the `backend` folder:

```python
from database import add_user
add_user(secret_key="NEW-KEY-HERE", name="Jane Doe", role="Analyst")
```

## Project structure

```
proofchain-app/
├── backend/
│   ├── app.py            # Flask routes (/api/login, /api/health)
│   ├── database.py       # SQLite setup, hashing, seed data
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx        # switches between LoginPage / SuccessPage
        ├── App.css        # dark navy theme matching the reference design
        ├── api.js         # fetch wrapper for the backend
        ├── icons.jsx       # inline SVG icons (shield, key, check, etc.)
        └── pages/
            ├── LoginPage.jsx    # Screen 1
            └── SuccessPage.jsx  # Screen 2
```

## Next steps (not built yet)

Screen 3 (the dashboard) isn't included — the "Go to Dashboard" button
currently just shows a placeholder alert. Say the word if you want that built
out next, along with routing (`react-router-dom`) instead of the simple
state-swap currently used in `App.jsx`.
