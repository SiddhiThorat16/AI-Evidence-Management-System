"""
AI Digital Evidence Management System -- backend.

Run with:  python app.py
Then the frontend (Vite dev server) proxies /api requests here.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS

from database import init_db, find_user_by_secret_key

app = Flask(__name__)
CORS(app)  # allow the React dev server (different port) to call this API

init_db()


@app.route("/api/login", methods=["POST"])
def login():
    payload = request.get_json(silent=True) or {}
    secret_key = (payload.get("secretKey") or "").strip()

    if not secret_key:
        return jsonify({"success": False, "message": "Secret key is required."}), 400

    user = find_user_by_secret_key(secret_key)

    if user is None:
        return jsonify({"success": False, "message": "Invalid secret key. Please try again."}), 401

    return jsonify({"success": True, "user": user}), 200


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
