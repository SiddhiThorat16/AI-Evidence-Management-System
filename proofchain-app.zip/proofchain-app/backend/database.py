"""
Database layer for the AI Digital Evidence Management System.

Uses SQLite for simplicity (zero external setup). Secret keys are never
stored in plain text -- only a salted hash (werkzeug's generate_password_hash),
the same approach normally used for passwords.

Swap this file out for a real database (Postgres/MySQL) later without
touching app.py, as long as you keep the same function signatures.
"""

import os
import sqlite3
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "evidence_system.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the users table and seed demo investigators if empty."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            secret_key_hash TEXT NOT NULL UNIQUE,
            name            TEXT NOT NULL,
            role            TEXT NOT NULL,
            created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()

    # Canonical demo users used by the UI.
    # Keep these values in sync with the login screen expectations.
    demo_users = [
        ("SNEHAL#30", "Snehal Supekar", "Investigator"),
        ("MYKEY123", "Siddhi Thorat", "Analyst"),
        ("key#50", "Divya Salunke", "Admin"),
    ]

    for secret_key, name, role in demo_users:
        cur.execute(
            "SELECT id FROM users WHERE name = ? AND role = ?",
            (name, role),
        )
        existing = cur.fetchone()

        if existing is None:
            cur.execute(
                "INSERT INTO users (secret_key_hash, name, role) VALUES (?, ?, ?)",
                (generate_password_hash(secret_key), name, role),
            )
        else:
            cur.execute(
                "UPDATE users SET secret_key_hash = ? WHERE name = ? AND role = ?",
                (generate_password_hash(secret_key), name, role),
            )

    conn.commit()
    for secret_key, name, role in demo_users:
        print(f"[seed] Demo user ready: {name} ({role}) | Secret key: {secret_key}")

    conn.close()


def find_user_by_secret_key(secret_key: str):
    """
    Secret keys are hashed with a random salt, so we can't look one up
    by an equality query -- instead we check the supplied key against
    every stored hash. Fine for a small set of authorized users; for a
    large user base, add a fast lookup (e.g. a separate indexed key ID
    the user also enters) instead of a full table scan.
    """
    from werkzeug.security import check_password_hash

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, secret_key_hash, name, role FROM users")
    rows = cur.fetchall()
    conn.close()

    for row in rows:
        if check_password_hash(row["secret_key_hash"], secret_key):
            return {"id": row["id"], "name": row["name"], "role": row["role"]}
    return None


def add_user(secret_key: str, name: str, role: str):
    """Helper for adding new authorized users (e.g. from an admin script)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (secret_key_hash, name, role) VALUES (?, ?, ?)",
        (generate_password_hash(secret_key), name, role),
    )
    conn.commit()
    conn.close()
